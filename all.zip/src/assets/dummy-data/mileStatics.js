const mileStatics = [
  {
    name: "Sat",
    mileStats: 6000,
  },
  {
    name: "Sun",
    mileStats: 5000,
  },
  {
    name: "Mon",
    mileStats: 7000,
  },
  {
    name: "Tue",
    mileStats: 5780,
  },
  {
    name: "Wed",
    mileStats: 4890,
  },
  {
    name: "Thu",
    mileStats: 6390,
  },
  {
    name: "Fri",
    mileStats: 5490,
  },
];

export default mileStatics;
